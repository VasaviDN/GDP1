//
//  CompatabilityQuestionCell.swift
//  SoulSwipe
//
//  Created by Chaparala,Jyothsna on 6/1/23.
//

import UIKit

class CompatabilityQuestionCell: UITableViewCell {

    
    @IBOutlet weak var questionTV: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  UtilityConstants.swift
//  SoulSwipe
//
//  Created by Adapa,Venkata Rayudu on 5/31/23.
//

import Foundation

let profiles: [Dictionary<String, String>] = [
    [
        "name": "John Smith",
        "job": "Designer",
        "compatablePercent": "92%",
        "image": "John Smith"
    ],
    [
        "name": "Tony Stark",
        "job": "Avenger",
        "compatablePercent": "86%",
        "image": "Tony Stark"
    ],
    [
        "name": "Tom Holland",
        "job": "Actor",
        "compatablePercent": "95.6%",
        "image": "Tom Holland"
    ],
    [
        "name": "Steve Rogers",
        "job": "Solider",
        "compatablePercent": "78%",
        "image": "Steve Rogers"
    ],
    [
        "name": "Scott",
        "job": "Engineer",
        "compatablePercent": "69%",
        "image": "Scott"
    ],
]



//
//  UtilityConstants.swift
//  SoulSwipe
//
//  Created by Adapa,Venkata Rayudu on 5/31/23.
//

import Foundation

var profiles: [Dictionary<String, String>] = [
    [
        "name": "John Smith",
        "job": "Designer",
        "compatablePercent": "92%",
        "image": "John Smith"
    ],
    [
        "name": "Tony Stark",
        "job": "Avenger",
        "compatablePercent": "86%",
        "image": "Tony Stark"
    ],
    [
        "name": "Tom Holland",
        "job": "Actor",
        "compatablePercent": "95.6%",
        "image": "Tom Holland"
    ],
    [
        "name": "Steve Rogers",
        "job": "Solider",
        "compatablePercent": "78%",
        "image": "Steve Rogers"
    ],
    [
        "name": "Scott",
        "job": "Engineer",
        "compatablePercent": "69%",
        "image": "Scott"
    ],
]

var blockedProfiles: [Dictionary<String, String>] = [
    [
        "name": "Dwayne Johnson",
        "job": "Designer",
        "compatablePercent": "92%",
        "image": "Dwayne Johnson"
    ],
    [
        "name": "Vin Diese",
        "job": "Avenger",
        "compatablePercent": "86%",
        "image": "Vin Diesel"
    ],
    [
        "name": "Tom Cruise",
        "job": "Actor",
        "compatablePercent": "95.6%",
        "image": "Tom Cruise"
    ],
    [
        "name": "Johnny Deep",
        "job": "Solider",
        "compatablePercent": "78%",
        "image": "Johnny Deep"
    ],
    [
        "name": "Leonardo Dicaprio",
        "job": "Engineer",
        "compatablePercent": "69%",
        "image": "Leonardo Dicaprio"
    ],
]

var favouriteProfiles: [Dictionary<String, String>] = [
    [
        "name": "John Smith",
        "job": "Designer",
        "compatablePercent": "92%",
        "image": "John Smith"
    ],
    [
        "name": "Tony Stark",
        "job": "Avenger",
        "compatablePercent": "86%",
        "image": "Tony Stark"
    ],
    [
        "name": "Tom Holland",
        "job": "Actor",
        "compatablePercent": "95.6%",
        "image": "Tom Holland"
    ],
    [
        "name": "Steve Rogers",
        "job": "Solider",
        "compatablePercent": "78%",
        "image": "Steve Rogers"
    ],
    [
        "name": "Scott",
        "job": "Engineer",
        "compatablePercent": "69%",
        "image": "Scott"
    ],
]

var likedProfiles: [Dictionary<String, String>] = [
    [
        "name": "John Smith",
        "job": "Designer",
        "compatablePercent": "92%",
        "image": "John Smith"
    ],
    [
        "name": "Tony Stark",
        "job": "Avenger",
        "compatablePercent": "86%",
        "image": "Tony Stark"
    ],
    [
        "name": "Tom Holland",
        "job": "Actor",
        "compatablePercent": "95.6%",
        "image": "Tom Holland"
    ],
    [
        "name": "Steve Rogers",
        "job": "Solider",
        "compatablePercent": "78%",
        "image": "Steve Rogers"
    ],
    [
        "name": "Scott",
        "job": "Engineer",
        "compatablePercent": "69%",
        "image": "Scott"
    ],
]

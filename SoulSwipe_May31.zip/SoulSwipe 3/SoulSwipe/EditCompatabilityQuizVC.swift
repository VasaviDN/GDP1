//
//  EditCompatabilityQuizVC.swift
//  SoulSwipe
//
//  Created by Chaparala,Jyothsna on 5/25/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class EditCompatabilityQuizVC: UIViewController {
    
    var selectedQuestionOneOptions: [String] = []
    
    let db = Firestore.firestore()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.getAnswersFromDB()
    }
    
    
    @IBOutlet var optionsBtn: [UIButton]!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func optionsBtn(_ sender: UIButton) {
        if(!self.selectedQuestionOneOptions.contains((sender.titleLabel?.text)!) && self.selectedQuestionOneOptions.count < 2) {
            sender.backgroundColor = UIColor.systemRed
            sender.tintColor = UIColor.white
            self.selectedQuestionOneOptions.append((sender.titleLabel?.text)!)
        } else if(self.selectedQuestionOneOptions.contains((sender.titleLabel?.text)!)){
            self.selectedQuestionOneOptions.remove(at: self.selectedQuestionOneOptions.lastIndex(of: (sender.titleLabel?.text)!)!)
            sender.backgroundColor = .clear
            sender.tintColor = UIColor.systemBlue
        } else {
            self.showAlertModal(title: "Info⚠️", message: "You can't select more than 2 options")
        }
    }
    
    
    @IBAction func continueBtn(_ sender: UIButton) {
        
        /* If no option is selected */
        if(self.selectedQuestionOneOptions.count == 0) {
            self.showAlertModal(title: "Warning❌", message: "Please select any two options of your choice.")
        }
        
        /* If less than 2 options are selected */
        else if(self.selectedQuestionOneOptions.count < 2) {
            self.showAlertModal(title: "Info⚠️", message: "Choose another option to proceed further.")
        }
        
        /* Everything is good */
        else {
//            let Q5 = self.storyboard?.instantiateViewController(withIdentifier: "s6") as! CompatabilityQuizQTwo
//            Q5.selectedQuestionOneOptions = self.selectedQuestionOneOptions
//            self.navigationController?.pushViewController(Q5, animated: true)
            self.updateDataToDB()
            self.showAlertModal(title: "Info", message: "Your options are updated to the database")
        }
    }
    
    
    
    /* Alert */
    private func showAlertModal(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
}

extension EditCompatabilityQuizVC {
    func getAnswersFromDB() {
        let quizAnswersRef = self.db.collection("CompatabilityQuiz").document((Auth.auth().currentUser?.email)!)
        
        quizAnswersRef.getDocument {
            (document, error) in
            if let document = document, document.exists {
                let details = document.data()!
                
                self.selectedQuestionOneOptions.append(contentsOf: details["questionOne"] as! [String])
                
                for i in self.optionsBtn {
                    if(self.selectedQuestionOneOptions.contains(i.titleLabel!.text!)) {
                        i.backgroundColor = UIColor.systemRed
                        i.tintColor = UIColor.white
                    }
                }
            }
        }
    }
    
    func updateDataToDB() {
        let quizAnswersRef = self.db.collection("CompatabilityQuiz").document((Auth.auth().currentUser?.email)!)
        
        /* Removing the previous answers */
        quizAnswersRef.updateData([
            "questionOne": FieldValue.delete()
        ]) { err in
            if let _ = err {
                self.showAlertModal(title: "Error", message: "Error in updating your profile")
            } else {
                self.showAlertModal(title: "Success✅", message: "Your Profile is updated successfully😃")
            }
        }
        
        /* Updating with the new answers */
        quizAnswersRef.updateData([
            "questionOne": FieldValue.arrayUnion(self.selectedQuestionOneOptions as [Any])
        ]) { err in
            if let _ = err {
                self.showAlertModal(title: "Error", message: "Error in updating your profile")
            } else {
                self.showAlertModal(title: "Success✅", message: "Your Profile is updated successfully😃")
            }
        }
    }
}
